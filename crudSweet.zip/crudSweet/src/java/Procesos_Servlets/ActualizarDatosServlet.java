package Procesos_Servlets;

import Procesos_Base_de_Datos.PersonaDao;
import Procesos_Base_de_Datos.Persona;
import java.io.IOException;
import java.sql.Date;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ActualizarDatosServlet")
public class ActualizarDatosServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int idPersona = Integer.parseInt(request.getParameter("id_persona"));
            String nombre = request.getParameter("nombre");
            String apPaterno = request.getParameter("ap_paterno");
            String apMaterno = request.getParameter("ap_materno");

            Date fechaNac = Date.valueOf(request.getParameter("fecha_nac"));

            String calle = request.getParameter("calle");
            String colonia = request.getParameter("colonia");
            String municipio = request.getParameter("municipio");
            int codigoPostal = Integer.parseInt(request.getParameter("codigo_postal"));

            Long telefono = Long.parseLong(request.getParameter("telefono"));

            String correo = request.getParameter("correo");
            String contrasena = request.getParameter("contrasena");

            Persona persona = new Persona();
            persona.setId_persona(idPersona);
            persona.setNombre(nombre);
            persona.setAp_paterno(apPaterno);
            persona.setAp_materno(apMaterno);
            persona.setFecha_nacimiento(fechaNac);
            persona.setCalle(calle);
            persona.setColonia(colonia);
            persona.setMunicipio(municipio);
            persona.setCodigo_postal(codigoPostal);
            persona.setTelefono(telefono);
            persona.setCorreo(correo);
            persona.setContrasena(contrasena);

            PersonaDao personaDao = new PersonaDao();
            boolean exito = personaDao.actualizar(persona);

            if (exito) {
                response.sendRedirect("perfil.jsp?mensaje=actualizado");
            } else {
                response.sendRedirect("perfil.jsp?mensaje=error");
            }
        } catch (Exception e) {
            // Manejo de errores
            e.printStackTrace();
            response.sendRedirect("perfil.jsp?mensaje=error");
        }
        
        
    }
}
