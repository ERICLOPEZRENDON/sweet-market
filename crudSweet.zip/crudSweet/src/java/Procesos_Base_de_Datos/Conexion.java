package Procesos_Base_de_Datos;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import jakarta.servlet.http.HttpSession;

public class Conexion {

    private Connection enlace;

public Conexion() {
    String rutaBD = "jdbc:postgresql://localhost:5432/sweet";
    try {
        // Registrar el controlador
        Class.forName("org.postgresql.Driver");
        
        // Establecer la conexión
        enlace = DriverManager.getConnection(rutaBD, "postgres", "root");
        System.out.println("Conectado A La Base De Datos de Sweet Market");
        
    } catch (ClassNotFoundException e) {
        System.out.println("ERROR: Controlador JDBC no encontrado - " + e.toString());
    } catch (SQLException e) {
        System.out.println("ERROR al conectar a la base de datos - " + e.toString());
    }
}


    public void cerrarEnlace() {
        try {
            if (enlace != null && !enlace.isClosed()) {
                enlace.close();
                System.out.println("Conexión a la DB Finalizada...");
            }
        } catch (SQLException ex) {
            System.out.println("ERROR al cerrar la conexión: " + ex.toString());
        }
    }

    public Connection getEnlace() {
        return enlace;
    }
}
