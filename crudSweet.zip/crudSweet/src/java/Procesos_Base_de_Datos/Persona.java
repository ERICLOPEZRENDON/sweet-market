package Procesos_Base_de_Datos;

import java.util.Date;
import jakarta.servlet.http.HttpSession;

public class Persona {
    private int id_persona;
    private String nombre;
    private String ap_paterno;
    private String ap_materno;
    private Date fecha_nacimiento;
    private String calle;
    private String colonia;
    private String municipio;
    private int codigo_postal;
    private Long telefono;
    private String correo;
    private String contrasena; // Nuevo campo para la contraseña

    // Getters y setters
    public int getId_persona() {
    return id_persona;
}

public void setId_persona(int id_persona) {
    this.id_persona = id_persona;
}

public String getNombre() {
    return nombre;
}

public void setNombre(String nombre) {
    this.nombre = nombre;
}

public String getAp_paterno() {
    return ap_paterno;
}

public void setAp_paterno(String ap_paterno) {
    this.ap_paterno = ap_paterno;
}

public String getAp_materno() {
    return ap_materno;
}

public void setAp_materno(String ap_materno) {
    this.ap_materno = ap_materno;
}

public Date getFecha_nacimiento() {
    return fecha_nacimiento;
}

public void setFecha_nacimiento(Date fecha_nacimiento) {
    this.fecha_nacimiento = fecha_nacimiento;
}

public String getCalle() {
    return calle;
}

public void setCalle(String calle) {
    this.calle = calle;
}

public String getColonia() {
    return colonia;
}

public void setColonia(String colonia) {
    this.colonia = colonia;
}

public String getMunicipio() {
    return municipio;
}

public void setMunicipio(String municipio) {
    this.municipio = municipio;
}

public int getCodigo_postal() {
    return codigo_postal;
}

public void setCodigo_postal(int codigo_postal) {
    this.codigo_postal = codigo_postal;
}

public Long getTelefono() {
    return telefono;
}

public void setTelefono(Long telefono) {
    this.telefono = telefono;
}

public String getCorreo() {
    return correo;
}

public void setCorreo(String correo) {
    this.correo = correo;
}

public String getContrasena() {
    return contrasena;
}

public void setContrasena(String contrasena) {
    this.contrasena = contrasena;
}
}
