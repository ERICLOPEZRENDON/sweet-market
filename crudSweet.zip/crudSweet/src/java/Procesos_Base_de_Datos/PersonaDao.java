package Procesos_Base_de_Datos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.http.HttpSession;

public class PersonaDao extends Conexion {

    public int alta(Persona persona) {
        int idCliente = -1;
        String sql = "INSERT INTO persona (nombre, ap_paterno, ap_materno, fecha_nac, calle, colonia, municipio, cp, tel_cel, correo_elec, contrasena) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = super.getEnlace().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, persona.getNombre());
            stmt.setString(2, persona.getAp_paterno());
            stmt.setString(3, persona.getAp_materno());
            stmt.setDate(4, new java.sql.Date(persona.getFecha_nacimiento().getTime()));
            stmt.setString(5, persona.getCalle());
            stmt.setString(6, persona.getColonia());
            stmt.setString(7, persona.getMunicipio());
            stmt.setInt(8, persona.getCodigo_postal());
            stmt.setLong(9, persona.getTelefono()); 
            stmt.setString(10, persona.getCorreo());
            stmt.setString(11, persona.getContrasena());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        idCliente = generatedKeys.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al registrar la persona: " + e.getMessage());
            e.printStackTrace();
        }
        return idCliente;
    }

    public boolean actualizar(Persona persona) {
    // Corregir el nombre del campo id_persona
    String sql = "UPDATE persona SET nombre = ?, ap_paterno = ?, ap_materno = ?, fecha_nac = ?, calle = ?, colonia = ?, municipio = ?, cp = ?, tel_cel = ?, correo_elec = ? WHERE id_persona = ?";

    try (Connection conn = super.getEnlace(); 
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, persona.getNombre());
        pstmt.setString(2, persona.getAp_paterno());
        pstmt.setString(3, persona.getAp_materno());
        pstmt.setDate(4, new java.sql.Date(persona.getFecha_nacimiento().getTime()));  // Convertir Date de Java a SQL
        pstmt.setString(5, persona.getCalle());
        pstmt.setString(6, persona.getColonia());
        pstmt.setString(7, persona.getMunicipio());
        pstmt.setInt(8, persona.getCodigo_postal());
        pstmt.setLong(9, persona.getTelefono());
        pstmt.setString(10, persona.getCorreo());
        pstmt.setInt(11, persona.getId_persona());  // Usar id_persona en lugar de id_cliente

        // Ejecutar la actualización
        int rowsUpdated = pstmt.executeUpdate();
        return rowsUpdated > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


    public Persona buscarPorID(int idCliente) {
        Persona persona = null;
        String sql = "SELECT * FROM persona WHERE id_persona = ?";

        try (Connection conn = super.getEnlace(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idCliente);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    persona = new Persona();
                    persona.setId_persona(rs.getInt("id_persona"));
                    persona.setNombre(rs.getString("nombre"));
                    persona.setAp_paterno(rs.getString("ap_paterno"));
                    persona.setAp_materno(rs.getString("ap_materno"));
                    persona.setFecha_nacimiento(rs.getDate("fecha_nac"));
                    persona.setCalle(rs.getString("calle"));
                    persona.setColonia(rs.getString("colonia"));
                    persona.setMunicipio(rs.getString("municipio"));
                    persona.setCodigo_postal(rs.getInt("cp"));
                    persona.setTelefono(rs.getLong("tel_cel"));
                    persona.setCorreo(rs.getString("correo_elec"));
                    persona.setContrasena(rs.getString("contrasena"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return persona;
    }

    public boolean eliminar(int idCliente) {
        String sql = "DELETE FROM persona WHERE id_persona = ?";
        try (Connection conn = super.getEnlace(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idCliente);
            int rowsDeleted = pstmt.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}