package Procesos_Base_de_Datos;

import java.math.BigInteger;
import java.util.Date;
import jakarta.servlet.http.HttpSession;

public class Main {
    public static void main(String[] args) {
        Conexion conexion = new Conexion();
        
        // Crear un objeto Persona sin asignar el id_persona, ya que se autoincrementa en la base de datos
        Persona persona = new Persona();
        persona.setNombre("Juan");
        persona.setAp_paterno("Pérez");
        persona.setAp_materno("González");
        persona.setFecha_nacimiento(new Date(100, 0, 1)); // Fecha de nacimiento (10 de enero de 2000)
        persona.setCalle("Av Siempre Viva");
        persona.setColonia("Ruiz Cortinez");
        persona.setMunicipio("Springfield");
        persona.setCodigo_postal(12345);
        persona.setTelefono(new Long("1234567890"));
        persona.setCorreo("juanperez@example.com");
        persona.setContrasena("juanperez");

        PersonaDao personaDao = new PersonaDao();
        int idCliente = personaDao.alta(persona);

        
    }
}
